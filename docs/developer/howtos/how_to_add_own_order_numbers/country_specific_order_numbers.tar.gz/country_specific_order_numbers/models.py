# django imports
from django.db import models
from django.utils.translation import ugettext_lazy as _

# lfs imports
from lfs.plugins import OrderNumberGenerator as Base


class OrderNumberGenerator(Base):
    """Generates order numbers and saves the last one. It has own number
    circles for german and abroad customers.

    **Attributes:**

    last_de
        The last stored/returned order number for german customers.

    last_other
        The last stored/returned order number for other coutnries.

    format_de
        The format of the integer part of the order number.

    format_de
        The format of the integer part of the order number.
    """
    format_de = models.CharField(blank=True, max_length=20)
    last_de = models.IntegerField(default=0)

    format_other = models.CharField(blank=True, max_length=20)
    last_other = models.IntegerField(default=0)

    def get_next(self, formatted=True):
        """Returns the next order number based on country of the selected
        invoice address.

        **Parameters:**

        formatted
            If True the number will be returned within the stored format.
        """
        if self.customer.selected_invoice_address.country.code == "de":
            self.last_de += 1
            format = self.format_de
            last = self.last_de
        else:
            self.last_other +=1
            format = self.format_other
            last = self.last_other

        self.save()

        if formatted:
            return format % last
        else:
            return last
