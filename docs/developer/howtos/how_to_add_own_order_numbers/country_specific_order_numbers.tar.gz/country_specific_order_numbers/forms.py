# django imports
from django import forms

# country_specific_order_numbers imports
from country_specific_order_numbers.models import OrderNumberGenerator


class OrderNumberGeneratorForm(forms.ModelForm):
    class Meta:
        model = OrderNumberGenerator
        exclude = ("id", )
