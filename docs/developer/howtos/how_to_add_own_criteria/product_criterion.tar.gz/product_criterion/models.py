# django imports
from django.db import models
from django.utils.translation import ugettext_lazy as _

# lfs imports
import lfs.cart.utils
from lfs.criteria.models import Criterion


class ProductCriterion(Criterion):
    value = models.CharField(u"SKU", max_length=100)

    def get_operators(self):
        return [
            [0, _(u"Is in cart")],
            [1, _(u"Is not in cart")],
        ]

    def is_valid(self):
        if self.product:
            return self.value == self.product.sku
        elif self.cart:
            result = any([self.value == item.product.sku for item in self.cart.get_items()])
            return result if self.operator == 0 else not result
        else:
            return False
